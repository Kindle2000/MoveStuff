#include <iostream>
#include <cstdio>
#include <windows.h>
#include <chrono>
#include <thread>


int main()
{
	Sleep(120000);//Initial sleep timer 
	std::string old_name = "D:\\Joker.mp4";//Where the file is located
	std::string new_name = "C:\\Users\\benli\\Documents\\Joker.mp4";// Where you want to move it and name.

	if (std::rename(old_name.c_str(), new_name.c_str()) != 0)//Function to move the file.
	{
		/*std::cout << "Error moving file";*/
		perror("Error moving file");//If it doesent work says what the error was.
	}
	else
		std::cout << "File moved successfully";//If the file is moved
	char moveon;
	std::cout << "Press any key to exit";
	std::cin >> moveon;

	return 0;
}